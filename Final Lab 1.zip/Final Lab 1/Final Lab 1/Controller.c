#include <stdio.h>
#include <stdlib.h>

#include "LinkedList.h"
#include "Partner.h"
#include "Controller.h"
#include "GetOnly.h"



int controller_loadFromText(char* path, LinkedList* pArrayListPartner)
{
    int retorno = -1;
    FILE* pArchivo;

    if (pArchivo!=NULL)
    {
        pArchivo=fopen(path, "r");
        parser_PartnerFromText(pArchivo,pArrayListPartner);
        retorno = 1;
    }

    fclose(pArchivo);

    return retorno;
}


int controller_loadFromTextFichaje(char* path, LinkedList* pArrayListFichaje)
{
    int retorno = -1;
    FILE* pArchivo;

    if (pArchivo!=NULL)
    {
        pArchivo=fopen(path, "r");
        parser_FichajeFromText(pArchivo,pArrayListFichaje);
        retorno = 1;
    }

    fclose(pArchivo);

    return retorno;
}




int controller_nextID(LinkedList* pArrayListPartner)
{
    int id = 0;
    int idAnterior;
    int intAuxiliar;
    ePartner* pPartner;
    int listLen;
    int i;

    if(pArrayListPartner != NULL)
    {
        listLen = ll_len(pArrayListPartner);
        if(listLen > 0)
        {
            for(i = 0; i<listLen; i++)
            {
                pPartner = (ePartner*)ll_get(pArrayListPartner,i);
                Partner_getId(pPartner,&intAuxiliar);
                if(intAuxiliar > id)
                {
                    idAnterior = id;
                    id = intAuxiliar;
                    if(idAnterior + 1 != id)
                    {
                        id = idAnterior;
                        break;
                    }
                }
            }
            id++;

        }
        else
        {
            id = 1;
        }
    }
    return id;
}




int controller_addPartner(LinkedList* pArrayListPartner)
{
    ePartner* pEmpleado;
    int retorno = -1;

    int idAuxiliar;

    char nombreChar[50];
    char apellidoChar[50];

    char dniChar[50];
    int dniCharAuxiliar;

    char passChar[50];


    pEmpleado = Partner_new();

    if(pArrayListPartner != NULL)
    {

        idAuxiliar = controller_nextID(pArrayListPartner);

        printf("Insert new name: ");
        fflush(stdin);
        gets(nombreChar);

        while(isOnlyLetters(nombreChar)==0)
        {
            printf("You've put a wrong name. Please, try again: ");
            fflush(stdin);
            gets(nombreChar);
        }
        stringToUpper(nombreChar);

        printf("Insert surname: ");
        fflush(stdin);
        gets(apellidoChar);

        while(isOnlyLetters(apellidoChar)==0)
        {
            printf("You've put a wrong surname. Please, try again: ");
            fflush(stdin);
            gets(apellidoChar);
        }
        stringToUpper(apellidoChar);


        printf("Insert DNI: ");
        fflush(stdin);
        gets(dniChar);

        while(isNumeric(dniChar)==0)
        {
            printf("You've put a wrong DNI. Please, try again: ");
            fflush(stdin);
            gets(dniChar);
        }
        dniCharAuxiliar= atoi(dniChar);


        printf("Insert pass: ");
        fflush(stdin);
        gets(passChar);

        while(isAlphaNumeric(passChar)==0)
        {
            printf("You've put a wrong password. Please, try again: ");
            fflush(stdin);
            gets(passChar);
        }
        stringToUpper(passChar);

        if(pEmpleado != NULL)
        {
            Partner_setId(pEmpleado, idAuxiliar);
            Partner_setNombre(pEmpleado, nombreChar);
            Partner_setApellido(pEmpleado, apellidoChar);
            Partner_setDNI(pEmpleado, dniCharAuxiliar);
            Partner_setClave(pEmpleado, passChar);
            ll_add(pArrayListPartner, pEmpleado);
            retorno = 0;
        }
    }
    return retorno;
}



int controller_editPartner(LinkedList* pArrayListPartner)
{
    ePartner* empleado;

    int retorno = -1;
    int i;

    char idChar[10];
    int idCharAuxiliar;
    int idObtenido;

    char opcionChar[50];
    int opcionCharAuxiliar;

    char nombreChar[50];

    char apellidoChar[50];

    char dniChar[50];
    int dniCharAuxiliar;

    char claveChar[50];


    if(pArrayListPartner != NULL)
    {
        printf("Insert the ID: ");
        fflush(stdin);
        gets(idChar);

        while(isNumeric(idChar)==0)
        {
            printf("You've put a wrong ID. Please, try again: ");
            fflush(stdin);
            gets(idChar);
        }
        idCharAuxiliar=atoi(idChar);

        for(i = 0; i< ll_len(pArrayListPartner); i++)
        {
            empleado = ll_get(pArrayListPartner,i);
            Partner_getId(empleado,&idObtenido);

            if(idObtenido == idCharAuxiliar)
            {
                printf("===========================================\n");
                printf("What do you want to edit? \n 1) Name \n 2) SName \n 3) DNI \n 4)Password \n");
                printf("===========================================\n\n");

                printf("\nSelect your option: ");
                fflush(stdin);
                gets(opcionChar);

                while(isNumeric(opcionChar)==0)
                {
                    printf("You've put a wrong option. Please, try again: ");
                    fflush(stdin);
                    gets(opcionChar);
                }
                opcionCharAuxiliar=atoi(opcionChar);

                switch(opcionCharAuxiliar)
                {
                case 1:
                    printf("Insert new name: ");
                    fflush(stdin);
                    gets(nombreChar);

                    while(isOnlyLetters(nombreChar)==0)
                    {
                        printf("You've put a wrong name. Please, try again: ");
                        fflush(stdin);
                        gets(nombreChar);
                    }

                    stringToUpper(nombreChar);
                    retorno = 0;
                    Partner_setNombre(empleado, nombreChar);
                    break;


                case 2:
                    printf("Insert new surname: ");
                    fflush(stdin);
                    gets(apellidoChar);

                    while(isOnlyLetters(apellidoChar)==0)
                    {
                        printf("You've put a wrong surname. Please, try again: ");
                        fflush(stdin);
                        gets(apellidoChar);
                    }

                    stringToUpper(apellidoChar);
                    retorno = 0;
                    Partner_setApellido(empleado, apellidoChar);
                    break;

                case 3:
                    printf("Insert new DNI: ");
                    fflush(stdin);
                    gets(dniChar);

                    while(isNumeric(dniChar)==0)
                    {
                        printf("You've put a wrong DNI. Please, try again: ");
                        fflush(stdin);
                        gets(dniChar);
                    }

                    dniCharAuxiliar= atoi(dniChar);
                    retorno = 0;
                    Partner_setDNI(empleado, dniCharAuxiliar);
                    break;

                case 4:
                    printf("Insert new password: ");
                    fflush(stdin);
                    gets(claveChar);

                    while(isAlphaNumeric(claveChar)==0)
                    {
                        printf("You've put a wrong password. Please, try again: ");
                        fflush(stdin);
                        gets(claveChar);
                    }

                    stringToUpper(claveChar);
                    retorno = 0;
                    Partner_setClave(empleado, claveChar);
                    break;

                default:
                    printf("You've put a wrong option. Please, try again: ");
                }
            }
        }
    }


    return retorno;
}


int controller_removePartner(LinkedList* pArrayListPartner, LinkedList* pArrayListFichaje)
{
    char idChar[10];
    int retorno = -1;
    int i,j;
    int contador = 0;
    int idCharAuxiliar;
    int idObtenido;
    int opcionAConfirmar;

    int idSocio;
    int idFichaje;

    char estado[50]="";

    ePartner* pPartner;
    eFichaje* pFichaje;

    if(pArrayListPartner != NULL)
    {
        printf("Insert the ID: ");
        fflush(stdin);
        gets(idChar);

        while(isNumeric(idChar)==0)
        {

            printf("You've put a wrong ID. Please, try again: ");
            fflush(stdin);
            gets(idChar);
        }

        idCharAuxiliar=atoi(idChar);

        for(i=0; i< ll_len(pArrayListPartner); i++)
        {
            pPartner = ll_get(pArrayListPartner,i);
            Partner_getId(pPartner, &idObtenido);

            if(idObtenido == idCharAuxiliar)
            {

                contador++;

                if (contador == 1)
                {
                    printf("\nAre you sure you want to remove Partner? (1 CONFIRMATION)\n");
                    printf("1) YES!\n");
                    printf("2) NO!\n");
                    scanf("%d",&opcionAConfirmar);
                }
                else
                {
                    printf("\nAre you sure you want to remove Partner? (2 CONFIRMATION)\n");
                    printf("1) YES!\n");
                    printf("2) NO!\n");
                    scanf("%d",&opcionAConfirmar);
                }

                switch(opcionAConfirmar)
                {

                case 1:
                    for(i=0; i < ll_len(pArrayListFichaje); i++)
                    {
                        pFichaje = ll_get(pArrayListFichaje,i);

                        Fichaje_getIDSocio(pFichaje,&idSocio);
                        Fichaje_getEstado(pFichaje, estado);

                        if(idObtenido==idSocio)
                        {
                            if(estado == "OUT")
                            {
                               Partner_delete(pPartner);
                                ll_remove(pArrayListPartner,i);
                            }
                            else
                            {
                                printf("No se puuede eliminar al socio\n");
                                break;
                            }
                        }

                    }


                    retorno = 0;
                    break;

                case 2:
                    retorno = -2;
                    break;

                default:
                    printf("You've put a wrong option. Please, try again: ");
                    retorno = -2;
                    break;
                }

            }
        }
    }

    contador = 0;
    return retorno;
}








int controller_ListPartner(LinkedList* pArrayListPartner)
{
    int retorno = -1;
    int i;

    int id;
    char nombre[50];
    char apellido[50];
    int dni;
    char clave[50];

    ePartner* pEmpleado;

    if(pArrayListPartner != NULL)
    {
        retorno = 0;
        printf("\n\nID-- \t\t   NAME \t\t SNAME \t\tDNI \t\tPASS \n\n");

        for(i=0; i < ll_len(pArrayListPartner); i++)
        {
            pEmpleado = ll_get(pArrayListPartner,i);
            Partner_getId(pEmpleado,&id);
            Partner_getNombre(pEmpleado, nombre);
            Partner_getApellido(pEmpleado, apellido);
            Partner_getDNI(pEmpleado,&dni);
            Partner_getClave(pEmpleado, clave);
            printf("------------------------------------------------------------------------\n");
            printf("%d -- %20s %20s %20d %20s\n", id, nombre, apellido, dni, clave);
        }
    }
    return retorno;
}


int controller_ListFichaje(LinkedList* pArrayListFichaje)
{
    int retorno = -1;
    int i;

    int idSocio;
    int idFichaje;
    int hora;
    int minuto;
    int dia;
    int mes;
    int anio;
    char estado[50];

    eFichaje* pFichaje;

    if(pArrayListFichaje != NULL)
    {
        retorno = 0;
        printf("\n\nIDF-- \t   IDS \t HORA \tMINUTO \tDIA \tMES \tANIO \tINGRESO\n\n");

        for(i=0; i < ll_len(pArrayListFichaje); i++)
        {
            pFichaje = ll_get(pArrayListFichaje,i);

            Fichaje_getIDSocio(pFichaje,&idSocio);
            Fichaje_getIDFichaje(pFichaje,&idFichaje);
            Fichaje_getHora(pFichaje,&hora);
            Fichaje_getMinuto(pFichaje,&minuto);
            Fichaje_getDia(pFichaje,&dia);
            Fichaje_getMes(pFichaje,&mes);
            Fichaje_getAnio(pFichaje,&anio);

            Fichaje_getEstado(pFichaje, estado);
            printf("------------------------------------------------------------------------\n");
            printf("%d - %d - %d - %d - %d - %d - %d - %s\n", idSocio, idFichaje, hora, minuto, dia, mes, anio, estado);
        }
    }
    return retorno;
}


int controller_ListFichajePorFecha(LinkedList* pArrayListFichaje, LinkedList* pArrayListPartner)
{
    int retorno = -1;
    int i,j;

    int idSocio;
    int idFichaje;
    int hora;
    int minuto;
    int dia;
    int mes;
    int anio;
    char estado[50];

    int id;
    char nombre[50];
    char apellido[50];
    int dni;
    char clave[50];

    int fechaMin;
    int fechaHora;
    int fechaDia;
    int fechaMes;
    int fechaAnio;


    eFichaje* pFichaje;
    ePartner* pEmpleado;

    if(pArrayListFichaje != NULL)
    {

        /*printf("\nInsete minuto: ");
        scanf("%d", &fechaMin);

        printf("\nInsete Hora: ");
        scanf("%d", &fechaHora);*/

        printf("\nInsete Dia: ");
        scanf("%d", &fechaDia);

        printf("\nInsete Mes: ");
        scanf("%d", &fechaMes);

        printf("\nInsete Anio: ");
        scanf("%d", &fechaAnio);

        retorno = 0;
        printf("\n\nIDF-- \t   IDS \t HORA \tMINUTO \tDIA \tMES \tANIO \tINGRESO\n\n");

        for(i=0; i < ll_len(pArrayListFichaje); i++)
        {
            pFichaje = ll_get(pArrayListFichaje,i);

            Fichaje_getIDSocio(pFichaje,&idSocio);
            Fichaje_getIDFichaje(pFichaje,&idFichaje);
            Fichaje_getHora(pFichaje,&hora);
            Fichaje_getMinuto(pFichaje,&minuto);
            Fichaje_getDia(pFichaje,&dia);
            Fichaje_getMes(pFichaje,&mes);
            Fichaje_getAnio(pFichaje,&anio);

            Fichaje_getEstado(pFichaje, estado);

            if(/*==minuto && fechaHora==hora &&*/ fechaDia == dia && fechaMes==mes && fechaAnio==anio)
            {
                for(j=0; j < ll_len(pArrayListPartner); j++)
                {
                    pEmpleado=ll_get(pArrayListPartner,j);
                    Partner_getId(pEmpleado,&id);
                    Partner_getNombre(pEmpleado, nombre);
                    Partner_getApellido(pEmpleado, apellido);
                    Partner_getDNI(pEmpleado,&dni);
                    Partner_getClave(pEmpleado, clave);
                    if(idSocio==id)
                    {
                        ll_sort(pArrayListPartner, Partner_ordenarPorDNI, 1);
                        printf("------------------------------------------------------------------------\n");
                        printf("%d -- %20s %20s %20d %20s\n", id, nombre, apellido, dni, clave);
                    }

                }
            }


        }
    }
    return retorno;
}




int controller_sortPartner(LinkedList* pArrayListPartner)
{
    int retorno = -1;

    if(pArrayListPartner != NULL)
    {
        Partner_sortPartner(pArrayListPartner);
        retorno = 0;
    }

    return retorno;
}


int controller_saveAsText(char* path, LinkedList* pArrayListPartner)
{

    FILE* pArchivo;
    ePartner* parterAux;

    int retorno = -1;
    int i;

    int* auxiliarID;
    char* auxiliarNombre;
    char* auxiliarApellido;
    int* auxiliarDNI;
    char* auxiliarClave;

    if(pArrayListPartner != NULL && path != NULL)
    {
        retorno = 1;
        auxiliarID = malloc(sizeof(int));
        auxiliarNombre = malloc(sizeof(char)*100);
        auxiliarApellido = malloc(sizeof(char)*100);
        auxiliarDNI = malloc(sizeof(int));
        auxiliarClave = malloc(sizeof(char)*100);

        pArchivo = fopen(path, "w");
        fprintf(pArchivo,"id,nombre,apellido,dni,clave\n");

        for(i=0; i< ll_len(pArrayListPartner); i++)
        {
            parterAux = ll_get(pArrayListPartner,i);
            Partner_getId(parterAux,auxiliarID);
            Partner_getNombre(parterAux, auxiliarNombre);
            Partner_getApellido(parterAux, auxiliarApellido);
            Partner_getDNI(parterAux,auxiliarDNI);
            Partner_getClave(parterAux, auxiliarClave);
            fprintf(pArchivo,"%d,%s,%s,%d,%s\n",*auxiliarID,auxiliarNombre,auxiliarApellido,*auxiliarDNI, auxiliarClave);
        }

        free(auxiliarNombre);
        free(auxiliarID);
        free(auxiliarApellido);
        free(auxiliarDNI);
        free(auxiliarClave);
        fclose(pArchivo);
    }
    return retorno;
}




void controller_firstMessage (void)
{
    printf("*********************************************************************************\n");
    printf("******************************** READ BEFORE USE ********************************\n");
    printf("******** YOU SHOULD LOAD THE LIST BEFORE USE THE LINKED LIST. IF YOU DONT *******\n");
    printf("**************************** THE LIST WILL BE REMPLACED ************************\n");
    printf("*********************************************************************************\n\n\n");

    printf("*********************************************************************************\n");
    printf("*************** THIS CODE HAS BEEN MADE FOR WINDOWS 7 (32 BITS) ****************\n");
    printf("*********************************************************************************\n\n\n");
}

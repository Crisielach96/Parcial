#include <stdio.h>
#include <stdlib.h>

#include "LinkedList.h"
#include "Partner.h"
#include "parser.h"


int parser_PartnerFromText(FILE* pFile , LinkedList* pArrayListPartner)
{

    ePartner* pPartner;

    char auxiliarID[50];
    char auxiliarNombre[50];
    char auxiliarApellido[50];
    char auxiliarDNI[50];
    char auxiliarClave[50];
    int retorno = -1;
    int flagPrimario = 1;

    if(pFile != NULL)
    {
        while(!feof(pFile))
        {

            if(flagPrimario)
            {
                flagPrimario = 0;

                fscanf(pFile, "%[^,],%[^,],%[^,],%[^,],%[^\n]\n", auxiliarID, auxiliarNombre, auxiliarApellido, auxiliarDNI, auxiliarClave);
            }

            fscanf(pFile, "%[^,], %[^,], %[^,], %[^,], %[^\n]\n", auxiliarID, auxiliarNombre, auxiliarApellido, auxiliarDNI, auxiliarClave);
            printf("%s - %s - %s - %s - %s\n", auxiliarID, auxiliarNombre, auxiliarApellido, auxiliarDNI, auxiliarClave);

            pPartner = Partner_newParametros(auxiliarID, auxiliarNombre, auxiliarApellido, auxiliarDNI, auxiliarClave);

            if(pPartner != NULL)
            {
                ll_add(pArrayListPartner, pPartner);
                retorno = 0;
            }
        }
    }

    return retorno;
}


int parser_FichajeFromText(FILE* pFile , LinkedList* pArrayListFichaje)
{

    eFichaje* pFichaje;

    char auxiliarIDFichaje[50];
    char auxiliarIDSocio[50];
    char auxiliarHora[50];
    char auxiliarMinuto[50];
    char auxiliarDia[50];
    char auxiliarMes[50];
    char auxiliarAnio[50];
    char auxiliarEstado[50];
    int retorno = -1;
    int flagPrimario = 1;

    if(pFile != NULL)
    {
        while(!feof(pFile))
        {

            if(flagPrimario)
            {
                flagPrimario = 0;

                fscanf(pFile, "%[^,], %[^,], %[^,], %[^,], %[^,], %[^,], %[^,], %[^\n]\n", auxiliarIDFichaje, auxiliarIDSocio, auxiliarHora, auxiliarMinuto, auxiliarDia, auxiliarMes, auxiliarAnio, auxiliarEstado);
            }

            fscanf(pFile, "%[^,], %[^,], %[^,], %[^,], %[^,], %[^,], %[^,], %[^\n]\n", auxiliarIDFichaje, auxiliarIDSocio, auxiliarHora, auxiliarMinuto, auxiliarDia, auxiliarMes, auxiliarAnio, auxiliarEstado);
            printf("%s - %s - %s - %s - %s - %s - %s - %s\n", auxiliarIDFichaje, auxiliarIDSocio, auxiliarHora, auxiliarMinuto, auxiliarDia, auxiliarMes, auxiliarAnio, auxiliarEstado);

            pFichaje = Fichaje_newParametros(auxiliarIDFichaje, auxiliarIDSocio, auxiliarHora, auxiliarMinuto, auxiliarDia, auxiliarMes, auxiliarAnio, auxiliarEstado);

            if(pFichaje != NULL)
            {
                ll_add(pArrayListFichaje, pFichaje);
                retorno = 0;
            }
        }
    }

    return retorno;
}

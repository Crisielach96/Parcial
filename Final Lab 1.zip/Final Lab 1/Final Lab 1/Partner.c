#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "Partner.h"


ePartner* Partner_new()
{
    ePartner* newPartner;

    newPartner = (ePartner*)malloc(sizeof(ePartner));

    if(newPartner != NULL)
    {
        newPartner->id = 0;
        strcpy(newPartner->nombre, " ");
        strcpy(newPartner->apellido, " ");
        newPartner->dni = 0;
        strcpy(newPartner->clave, " ");
    }

    return newPartner;
}


eFichaje* fichaje_new()
{
    eFichaje* newFichaje;

    newFichaje = (eFichaje*)malloc(sizeof(eFichaje));

    if(newFichaje != NULL)
    {
        newFichaje->idFichaje = 0;
        newFichaje->idSocio = 0;
        newFichaje->hora = 0;
        newFichaje->minuto = 0;
        newFichaje->dia = 0;
        newFichaje->mes = 0;
        newFichaje->anio = 0;
        strcpy(newFichaje->estado, " ");

    }

    return newFichaje;
}


ePartner* Partner_newParametros(char* idStr, char* nombreStr, char* apellidoStr, char* dniStr, char* claveStr)
{
    ePartner* newPartner;
    newPartner = Partner_new();

    int auxiliarId;
    int auxiliarDNI;

    auxiliarId= atoi(idStr);
    auxiliarDNI= atoi(dniStr);


    if(newPartner != NULL && idStr != NULL && nombreStr != NULL && apellidoStr != NULL && dniStr != NULL && claveStr != NULL)
    {
        Partner_setNombre(newPartner, nombreStr);
        Partner_setId(newPartner, auxiliarId);
        Partner_setApellido(newPartner, apellidoStr);
        Partner_setDNI(newPartner, auxiliarDNI);
        Partner_setClave(newPartner, claveStr);
    }
    return newPartner;
}


eFichaje* Fichaje_newParametros(char* idFichajeStr, char* idSocioStr, char* horaStr, char* minutoStr, char* diaStr, char* mesStr, char* anioStr, char* estadoStr)
{
    eFichaje* newFichaje;
    newFichaje = fichaje_new();

    int auxiliarIDSocio;
    int auxiliarIDFichaje;
    int auxiliarHora;
    int auxiliarMinuto;
    int auxiliarDia;
    int auxiliarMes;
    int auxiliarAnio;

    auxiliarIDSocio= atoi(idSocioStr);
    auxiliarIDFichaje= atoi(idFichajeStr);
    auxiliarHora = atoi(horaStr);
    auxiliarMinuto = atoi(minutoStr);
    auxiliarDia = atoi(diaStr);
    auxiliarMes = atoi(mesStr);
    auxiliarAnio = atoi(anioStr);


    if(newFichaje != NULL && idFichajeStr != NULL && idSocioStr != NULL && horaStr != NULL && minutoStr != NULL && diaStr != NULL && mesStr != NULL && anioStr != NULL && estadoStr != NULL)
    {
        Fichaje_setIDFichaje(newFichaje, auxiliarIDFichaje);
        Fichaje_setIDSocio(newFichaje, auxiliarIDSocio);
        Fichaje_setHora(newFichaje, auxiliarHora);
        Fichaje_setMinuto(newFichaje, auxiliarMinuto);
        Fichaje_setDia(newFichaje, auxiliarDia);
        Fichaje_setMes(newFichaje, auxiliarMes);
        Fichaje_setAnio(newFichaje, auxiliarAnio);
        Fichaje_setEstado(newFichaje, estadoStr);
    }
    return newFichaje;
}




void Partner_delete(ePartner* this)
{
    if(this!=NULL)
    {
        free(this);
    }
}


int Partner_setId(ePartner* this,int id)
{
    int retorno = -1;
    if(this != NULL)
    {
        if(id >= 0)
        {
            this->id = id;
            retorno = 0;
        }
    }
    return retorno;
}


int Partner_getId(ePartner* this,int* id)
{
    int retorno = -1;

    if (this!=NULL && id !=NULL)
    {
        *id = this->id;
        retorno = 0;
    }
    return retorno;

}

int Partner_setNombre(ePartner* this,char* nombre)
{
    int retorno=-1;
    if(this!=NULL && nombre!=NULL)
    {
        strcpy(this->nombre,nombre);
        retorno=0;
    }
    return retorno;
}





int Partner_getNombre(ePartner* this,char* nombre)
{
    int retorno=-1;
    if(this!=NULL && nombre!=NULL)
    {
        strcpy(nombre,this->nombre);
        retorno=0;
    }
    return retorno;
}


int Partner_setApellido(ePartner* this,char* apellido)
{
    int retorno=-1;
    if(this!=NULL && apellido!=NULL)
    {
        strcpy(this->apellido,apellido);
        retorno=0;
    }
    return retorno;
}


int Partner_getApellido(ePartner* this,char* apellido)
{
    int retorno=-1;
    if(this!=NULL && apellido!=NULL)
    {
        strcpy(apellido,this->apellido);
        retorno=0;
    }
    return retorno;
}


int Partner_setDNI(ePartner* this,int DNI)
{
    int retorno = -1;
    if(this != NULL)
    {
        if(DNI >= 0)
        {
            this->dni = DNI;
            retorno = 0;
        }
    }
    return retorno;
}


int Partner_getDNI(ePartner* this,int* DNI)
{
    int retorno = -1;
    if(this != NULL && DNI != NULL)
    {
        *DNI = this->dni;
        retorno = 0;
    }
    return retorno;
}




int Partner_setClave(ePartner* this,char* clave)
{
    int retorno=-1;
    if(this!=NULL && clave!=NULL)
    {
        strcpy(this->clave,clave);
        retorno=0;
    }
    return retorno;
}


int Partner_getClave(ePartner* this,char* clave)
{
    int retorno=-1;
    if(this!=NULL && clave!=NULL)
    {
        strcpy(clave,this->clave);
        retorno=0;
    }
    return retorno;
}






//______________________

int Fichaje_setIDSocio(eFichaje* this,int idSocio)
{
    int retorno = -1;
    if(this != NULL)
    {
        if(idSocio >= 0)
        {
            this->idSocio = idSocio;
            retorno = 0;
        }
    }
    return retorno;
}

int Fichaje_setIDFichaje(eFichaje* this,int idFichaje)
{
    int retorno = -1;
    if(this != NULL)
    {
        if(idFichaje >= 0)
        {
            this->idFichaje = idFichaje;
            retorno = 0;
        }
    }
    return retorno;
}

int Fichaje_setHora(eFichaje* this,int hora)
{
    int retorno = -1;
    if(this != NULL)
    {
        if(hora >= 0)
        {
            this->hora = hora;
            retorno = 0;
        }
    }
    return retorno;
}

int Fichaje_setMinuto(eFichaje* this,int minuto)
{
    int retorno = -1;
    if(this != NULL)
    {
        if(minuto >= 0)
        {
            this->minuto = minuto;
            retorno = 0;
        }
    }
    return retorno;
}

int Fichaje_setDia(eFichaje* this,int dia)
{
    int retorno = -1;
    if(this != NULL)
    {
        if(dia >= 0)
        {
            this->dia = dia;
            retorno = 0;
        }
    }
    return retorno;
}

int Fichaje_setMes(eFichaje* this,int mes)
{
    int retorno = -1;
    if(this != NULL)
    {
        if(mes >= 0)
        {
            this->mes = mes;
            retorno = 0;
        }
    }
    return retorno;
}

int Fichaje_setAnio(eFichaje* this,int anio)
{
    int retorno = -1;
    if(this != NULL)
    {
        if(anio >= 0)
        {
            this->anio = anio;
            retorno = 0;
        }
    }
    return retorno;
}

int Fichaje_setEstado(eFichaje* this,char* estado)
{
    int retorno=-1;
    if(this!=NULL && estado!=NULL)
    {
        strcpy(this->estado,estado);
        retorno=0;
    }
    return retorno;
}




//___________________

int Fichaje_getIDSocio(eFichaje* this,int* idSocio)
{
    int retorno = -1;
    if(this != NULL && idSocio != NULL)
    {
        *idSocio = this->idSocio;
        retorno = 0;
    }
    return retorno;
}

int Fichaje_getIDFichaje(eFichaje* this,int* idFichaje)
{
    int retorno = -1;
    if(this != NULL && idFichaje != NULL)
    {
        *idFichaje = this->idFichaje;
        retorno = 0;
    }
    return retorno;
}

int Fichaje_getHora(eFichaje* this,int* hora)
{
    int retorno = -1;
    if(this != NULL && hora != NULL)
    {
        *hora = this->hora;
        retorno = 0;
    }
    return retorno;
}

int Fichaje_getMinuto(eFichaje* this,int* minuto)
{
    int retorno = -1;
    if(this != NULL && minuto != NULL)
    {
        *minuto = this->minuto;
        retorno = 0;
    }
    return retorno;
}

int Fichaje_getDia(eFichaje* this,int* dia)
{
    int retorno = -1;
    if(this != NULL && dia != NULL)
    {
        *dia = this->dia;
        retorno = 0;
    }
    return retorno;
}

int Fichaje_getMes(eFichaje* this,int* mes)
{
    int retorno = -1;
    if(this != NULL && mes != NULL)
    {
        *mes = this->mes;
        retorno = 0;
    }
    return retorno;
}

int Fichaje_getAnio(eFichaje* this,int* anio)
{
    int retorno = -1;
    if(this != NULL && anio != NULL)
    {
        *anio = this->anio;
        retorno = 0;
    }
    return retorno;
}


int Fichaje_getEstado(eFichaje* this,char* estado)
{
    int retorno=-1;
    if(this!=NULL && estado!=NULL)
    {
        strcpy(estado,this->estado);
        retorno=0;
    }
    return retorno;
}









int Partner_sortPartner(LinkedList* pArrayListPartner)
{
    int opcion;
    int retorno = -1;

    if(pArrayListPartner != NULL)
    {
                printf("\n===========================================\n");
                printf("How do you want to order? \n 1) By DNI \n 2)Exit. \n");
                printf("===========================================\n\n");

                printf("\nSelect your option: ");
                scanf("%d", &opcion);

            switch(opcion)
            {
                case 1:
                    printf("\n*************** PLEASE - Wait a moment.\n\n");
                    printf("\n*************** \n\n");
                    printf("\n*************** \n\n");
                    printf("\n*************** DONE.\n\n");
                    ll_sort(pArrayListPartner, Partner_ordenarPorDNI, 1);
                    break;

                default:
                    printf("\nInvalid option!");
            }

        retorno = 0;
    }

    return retorno;
}


int Partner_ordenarPorDNI(void* variableA, void* variableB)
{
    int DNIA;
    int DNIB;
    int retorno = 0;

    Partner_getDNI(variableA, &DNIA);
    Partner_getDNI(variableB, &DNIB);

    if(DNIA > DNIB)
    {
        retorno = 1;
    }
    else if(DNIA < DNIB)
    {
        retorno = -1;
    }

    return retorno;
}


